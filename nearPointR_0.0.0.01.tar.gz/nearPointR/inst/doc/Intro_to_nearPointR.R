## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
category <- "accommodation.hotel"
longitude <- 7.6009394 # When executing computer obtain this from Google location API
latitude <- 51.956711 # When executing computer obtain this from Google location API
api_url <- paste0("https://api.geoapify.com/v2/places?categories=",
                     category,
                     "&filter=circle:",
                     longitude,",",
                     latitude,
                     ",5000&bias=proximity:",
                     longitude,",",
                     latitude,
                     "&lang=en&limit=50&apiKey=YOUR API KEY"
  )
print(api_url)

## -----------------------------------------------------------------------------
library(nearPointR)

## -----------------------------------------------------------------------------
basemap <- "OpenStreetMap"
current_location(basemap)

## -----------------------------------------------------------------------------
basemap <- "EsriWorldImagery"
current_location(basemap)

## -----------------------------------------------------------------------------
category <- "healthcare.pharmacy"
basemap <- "EsriWorldImagery"
nearest_locations(category,basemap)

## -----------------------------------------------------------------------------
category <- "healthcare.hospital"
basemap <- "OpenStreetMap"
nearest_locations(category,basemap)

## -----------------------------------------------------------------------------
category <- "healthcare.hospital"
navigate_to_closest(category)

## -----------------------------------------------------------------------------
category <- "commercial.supermarket"
show_list(category)

## -----------------------------------------------------------------------------
category <- "healthcare.pharmacy"
output_format <- "kml"
download_list(category,output_format)

